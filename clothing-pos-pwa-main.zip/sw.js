const CACHE_NAME = "clothing-pos-pwa-v107";
const CORE_ASSETS = [
  "./",
  "./index.html",
  "./design-tokens.css",
  "./styles.css",
  "./app.js",
  "./assets/default-logo.js",
  "./manifest.webmanifest",
  "./assets/vendor/pdfmake.min.js",
  "./assets/vendor/pdfmake-fonts.js",
  "./assets/vendor/qrcode.min.js",
  "./assets/vendor/html2canvas.min.js",
  "./assets/icon-192.png",
  "./assets/icon-512.png",
  "./assets/catalog-preview.png",
  "./assets/reports-preview.png",
  "./assets/invoice-preview.png",
  "./assets/product-form-preview.png"
];

self.addEventListener("install", event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(CORE_ASSETS)));
  self.skipWaiting();
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request)
        .then(response => {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
          return response;
        })
        .catch(() => caches.match("./index.html"));
    })
  );
});
